package bg.sofia.uni.fmi.mjt.cocktail.server;


public record Command(String command, String[] arguments) {
}
