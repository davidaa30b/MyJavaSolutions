import bg.sofia.uni.fmi.mjt.myfitnesspal.diary.DailyFoodDiary;
import bg.sofia.uni.fmi.mjt.myfitnesspal.diary.Meal;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

    }
}