package bg.sofia.uni.fmi.mjt.news.exceptions;

public class RateLimitedException extends Exception {
    public RateLimitedException(String message) {
        super(message);
    }
}