package bg.sofia.uni.fmi.mjt.news.exceptions;

public class ApiKeyInvalidException extends Exception {
    public ApiKeyInvalidException(String message) {
        super(message);
    }
}
