package wrapper;

import articles.TopHeadLinesArticles;
import exceptions.ApiKeyInvalidException;
import exceptions.ApiKeyMissingException;
import exceptions.NewsAPIWrapperException;
import exceptions.ParameterInvalidException;
import exceptions.ParametersMissingException;
import exceptions.RateLimitedException;

public interface NewsAPIWrapper {
    TopHeadLinesArticles getArticlesBySpecifier(
            String[] keywords, String country, String category, int page, int pageSize)
            throws NewsAPIWrapperException, RateLimitedException, ParameterInvalidException,
            ApiKeyInvalidException, ParametersMissingException, ApiKeyMissingException;

}
