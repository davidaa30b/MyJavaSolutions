package exceptions;

public class ApiKeyInvalidException extends Exception {
    public ApiKeyInvalidException(String message) {
        super(message);
    }
}
