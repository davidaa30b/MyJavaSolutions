package exceptions;

public class ParametersMissingException extends Exception {
    public ParametersMissingException(String message) {
        super(message);
    }
}