package exceptions;

public class ParameterInvalidException extends Exception {
    public ParameterInvalidException(String message) {
        super(message);
    }
}
