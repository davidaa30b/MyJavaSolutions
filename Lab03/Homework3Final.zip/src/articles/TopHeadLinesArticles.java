package articles;

import java.util.Arrays;

public record TopHeadLinesArticles(String status, int totalResults, NewsArticle[] articles) {

    @Override
    public boolean equals(Object obj) {

        TopHeadLinesArticles other = (TopHeadLinesArticles) obj;

        return this.status.equals(other.status) &&
                this.totalResults == other.totalResults &&
                Arrays.equals(this.articles, other.articles);
    }

    public void printAllArticles() {
        for (var article : articles
             ) {
            System.out.println("--------------------------------------");
            System.out.println("author : " + article.author());
            System.out.println("content : " + article.content());
            System.out.println("description : " + article.description());
            System.out.println("url : " + article.url());
            System.out.println("title : " + article.title());
            System.out.println("publishedAt : " + article.publishedAt());
            System.out.println("urlToImage : " + article.urlToImage());
            System.out.println("id : " + article.source().id());
            System.out.println("name : " + article.source().name());
            System.out.println("--------------------------------------");


        }
    }
}
