package bg.sofia.uni.fmi.mjt.mail;

public record Account(String emailAddress, String name) {
}