package bg.sofia.uni.fmi.mjt.mail;

public record Rule(String ruleDefinition,String folderPath,int priority) {


}
